#include <string>
#include <iostream>
#include <vector>
#include "card.h"
#include <fstream>
#include <math.h>
#include <chrono>
using namespace std;
using namespace std::chrono;
struct returnArr{
  int returnArr[3];
};
int computeSumProfit(card cardList[],int listSize){
  int sum = 0;
  for(int i =0; i < listSize;i++){
    sum += cardList[i].getPrice();
    sum -= cardList[i].getCost();
  }
  return sum;
}
struct returnArr computeMaxProfit(card cardList[],int constraint,int listSize,std::vector<card> &maxCardList){
  struct returnArr returnValues;
  int maxCombinations = pow(2,listSize);
  int maxProfit = 0;
  card tempArr [listSize] = {};
  card masterArr [listSize] = {};
  std::vector<card> tempCardList; 
  int tempProfit = computeSumProfit(cardList,listSize);
  int tempCost = 0;
  int cardsMaxProfit =0;
  
  for(int i = 0; i < listSize;i++){
    tempCost+=cardList[i].getCost();
    maxCardList.push_back(cardList[i]);
  }
  if(tempCost <= constraint){// make it =<
    returnValues.returnArr[0] = listSize;
    returnValues.returnArr[1] = tempProfit;
    returnValues.returnArr[2] = listSize;
    return returnValues;
  }
  
  for(int i = 0; i < (maxCombinations);i++){
    int loc = 0;
    tempCost = 0;
    tempProfit = 0;
    tempCardList.clear();
    

    for(int j = 0; j < listSize;j++){
      if(i &(1<<j)){
      //cout<<"Checking set loop"<<endl;
      //cardList[j].show();
      //cout<<"Cost per card"<<cardList[j].getCost()<<endl;
      tempCardList.push_back(cardList[j]);
      tempCost += cardList[j].getCost();
      //cout<<"Temp cost after adding"<<tempCost<<endl;
      tempProfit += cardList[j].getPrice();
      tempProfit -= cardList[j].getCost();
      tempArr[loc] = cardList[j];
      //cout<<"Loc:"<<loc<<endl;
      loc+=1;
      } 
    }

    if(tempProfit > maxProfit && tempCost <= constraint){
      maxProfit = tempProfit;
      maxCardList = tempCardList;
      for(int k = 0; k < loc;k++){//loc used to be listSize

	masterArr[k] = tempArr[k];
      }
      //cout<<"Temp temp Profit"<<tempTempProfit<<endl;
      //cout<<"Temp temp Cost"<<tempTempCost<<endl;
      //cout<<"--------------"<<endl;
    }
  }
  
  for(int k = 0; k < listSize;k++){
    // masterArr[k].show();
    if(masterArr[k].getName()!="-1"){
      cardsMaxProfit +=1;
    }
  }

 
  //cout<<cardsMaxProfit<<endl;
  //int outPut[3] ={listSize,maxProfit,cardsMaxProfit}
  //cout<<listSize<<endl;
  
  returnValues.returnArr[0] = listSize;
  returnValues.returnArr[1] = maxProfit;
  returnValues.returnArr[2] = cardsMaxProfit;
  return returnValues;
}
int main(int argc, char*argv[]){
  if(argc < 4 ){cout<<"ERROR:Invalid Argnums (OUTPUT: program1 <market-price-file> <price-list-file> <output-file> )"<<endl;}
  else{
    string marketFileName = argv[1];
    string priceFileName = argv[2];
    ifstream inFile;
    ofstream outPutFile("outPut.txt");
    string priceStr;
    int priceInt;
    inFile.open(marketFileName);
    char line[64];
    inFile.getline(line,64);
    int count1 = stoi(line);
    card cardListPrice [count1] ={};
    for(int i = 0; i < count1;i++){
      inFile.getline(line,64);
      int j =0;
      string line1 = "";
      priceInt = 0;
      priceStr = " ";
      while(line[j] != ' '){
        line1+=line[j];
        j++;	
      }
      j+=1;
      while(line[j] != '\0'){
        priceStr+=line[j];
	      j+=1;
      }
      priceInt = stoi(priceStr);
      cardListPrice[i] = card(line1,-1,priceInt);//cost and marketprice
      //cout<<cardListPrice[i].getName()<<endl;
    }
    inFile.close();
    /*
      Have a overarching While loop
      Parse the first line in order to get the amount and the constraint
      then use a for loop to add the cards to an array
      then look through the marketcards to find the market price if the marketprice isnt there for one of the cards then return an error
      call the powerSet function
      move to the next problem, if the problem doesnt exist then exit the for loop 
     */
    inFile.open(priceFileName);
    int cardNumList = 0;
    string strLine = "";
    string testInt = "";
    int constraint = 0;
    while(inFile){
      testInt = "";
      getline(inFile,strLine);
      //cout<<"strLine --->"<<strLine<<endl;
      if(strLine == ""){
	break;
      }
      int maxProfit = 0;
      testInt+=strLine[0];
      // cout<<"Before end stoi"<<endl;
      // cout<<strLine<<endl;
      // cout<<testInt<<endl;
      // cout<<"testInt"<<testInt<<endl;
      if(isdigit(testInt[0]) == false){
        break;
      }
      cardNumList = stoi(testInt);
      // cout<<"after end stoi"<<endl;
      //cout<<cardNumList<<endl;
      //cout<<strLine<<endl;
      constraint = stoi(strLine.substr(2));
      card playerCards[cardNumList]={};
      for(int i =0; i < cardNumList;i++){
	getline(inFile,strLine);
	//cout<<"strLine2 --->"<<strLine<<endl;
	if(strLine ==""){
	  break;
	}
	size_t t = strLine.find(" ");
	bool found = false;
	int price =0;
	for(int j = 0; j < count1;j++){
	  if(cardListPrice[j].getName() == strLine.substr(0,t)){
	    price = cardListPrice[j].getPrice();
	    found = true;
	  }
	}
	if(found == false){
	  cout<<"ERROR: card in price not in market file"<<endl;
	  return -1;
	}
	playerCards[i] = card(strLine.substr(0,t),stoi(strLine.substr(t+1)),price);
	
      }
      auto start = high_resolution_clock::now();
      struct returnArr valueHolder;
      /*
      for(int i = 0;i < cardNumList;i++){
	playerCards[i].show();
	cout<<"-p-"<<endl;
	}*/
      std::vector<card> maxCardList;
      valueHolder = computeMaxProfit(playerCards,constraint,cardNumList,maxCardList);
      auto stop = high_resolution_clock::now();
      //auto duration = duration_cast<seconds>(stop-start);
      duration<double>duration = stop-start;
      //cout<<" Duration in milliseconds not microseconds"<<duration.count()<<endl;
      //cout<<maxProfit<<endl;
      //ofstream outPutFile("outPut.txt");
      //outPutFile.open("outPut.txt");
      string arg1 = to_string(valueHolder.returnArr[0]);
      string arg2 = to_string(valueHolder.returnArr[1]);
      string arg3 = to_string(valueHolder.returnArr[2]);
      string arg4 = to_string(duration.count());
      string lenOfCards = to_string(maxCardList.size());
      // cout<<"Length of the cardList"<<maxCardList.size()<<endl;
      outPutFile<<arg1<<" ";
      outPutFile<<arg2<<" ";
      outPutFile<<arg3<<" ";
      outPutFile<<lenOfCards<<" ";
      outPutFile<<arg4<<"\n";
      // cout<<"Outputted"<<arg1<<" "<<arg2<<"arg3:"<<arg3<<"arg4: "<<arg4<<endl;
      for(auto begin = maxCardList.begin();begin != maxCardList.end();begin++){
        outPutFile<<(*begin).getName()<<"\n";
        //cout<<"Part of the vector: "<<(*begin).getName()<<endl;
      }
      //outPutFile<<to_string(valueHolder.returnArr[0])<<"\n";
      //outPutFile<<to_string(valueHolder.returnArr[1])<<"\n";
      //outPutFile<<to_string(valueHolder.returnArr[2])<<"\n";
      //outPutFile<<duration.count()<<"\n";
      
    }
    outPutFile.close();
    inFile.close();
    //cout<<argv[0]<<endl;// Should be the program name
    //cout<<argv[1]<<endl;//Should be -m
    //cout<<argv[2]<<endl; // should be the market list
    //cout<<argv[3]<<endl; //should be -p
    //cout<<argv[4]<<endl; // price list file
    
   //card hi = card("Brandon Ciaravino",32,12);
  //cout<<hi.getName()<<endl;
  }
}
