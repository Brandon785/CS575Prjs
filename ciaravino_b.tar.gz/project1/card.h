#ifndef __CARD_H
#define __CARD_H
#include <iostream>
#include <string>
using namespace std;

class card{
 public:
  card();
  card(string name,int cost,int marketPrice);
  int getCost();
  string getName();
  int getPrice();
  void setPrice(int price);
  void setName(string name);
  void setCost(int cost);
  void show();
 private:
  int mrktPrice;
  int cardCost;
  string cardName;
};
#endif
