#include "card.h"
card::card(string name,int cost,int marketPrice){
  mrktPrice = marketPrice;
  cardName = name;
  cardCost = cost;
}
card::card(){
  mrktPrice = 0;
  cardName ="-1";
  cardCost = 0;
}
int card::getCost(){
  return cardCost;
}
string card::getName(){
  return cardName;
}
int card::getPrice(){
  return mrktPrice;
}
void card::setPrice(int price){
  mrktPrice = price;
}
void card::setCost(int cost){
  cardCost = cost;
}
void card::setName(string name){
  cardName = name;
}
void card::show(){
  cout<<cardName<<" cardCost: "<<getCost()<<" market Price: "<<getPrice()<<endl;
}
